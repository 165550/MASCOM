/**
 * Created by JaysonGCS on 27/6/16.
 */
$(function () {
    $('.navbar-toggle#sidemenu').click(function () {
        $('.navbar-nav').toggleClass('slide-in');
        $('.side-body').toggleClass('body-slide-in');
        $('#search').removeClass('in').addClass('collapse').slideUp(200);

        /// uncomment code for absolute positioning tweek see top comment in css
        //$('.absolute-wrapper').toggleClass('slide-in');

    });

    $('.navbar-nav#sidemenuonly>li').click(function (e) {
        e.preventDefault();
        $(this).parent().find('li').removeClass('active');
        $(this).addClass('active');
    });


    // Remove menu for searching
    $('#search-trigger').click(function () {
        $('.navbar-nav').removeClass('slide-in');
        $('.side-body').removeClass('body-slide-in');

        /// uncomment code for absolute positioning tweek see top comment in css
        //$('.absolute-wrapper').removeClass('slide-in');

    });
});