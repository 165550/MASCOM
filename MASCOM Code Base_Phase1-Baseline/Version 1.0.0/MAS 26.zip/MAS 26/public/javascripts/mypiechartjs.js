/**
 * Created by JaysonGCS on 5/7/16.
 */

$(document).ready(function () {
/*
    var data = [],
        series = Math.floor(Math.random() * 6) + 3;

    for (var i = 0; i < series; i++) {
        data[i] = {
            label: "Series" + (i + 1),
            data: Math.floor(Math.random() * 100) + 1
        }

    }

    function labelFormatter(label, series) {
        return "<div style='font-size:8pt; text-align:center; padding:2px; color:white;'>" + label + "<br/>" + Math.round(series.percent) + "%</div>";
    }

    $.plot($("#placeholder"), data, {
        series: {
            pie: {
                show: true,
                radius: 1,
                label: {
                    show: true,
                    radius: 3 / 4,
                    formatter: labelFormatter,
                    background: {
                        opacity: 0.5,
                        color: "#000"
                    }
                }
            }
        },
        legend: {
            show: false
        }
    });*/
    /*   $.plot($("#placeholder"), data, {
     series: {
     pie: {
     show: true,
     radius: 1,
     label: {
     show: true,
     radius: 3/4,
     formatter: labelFormatter,
     background: {
     opacity: 0.5,
     color: '#000'
     }
     }
     }
     },
     legend: {
     show: false
     }
     });*/


    //  $.plot($("#placeholder"), [ [[0, 0], [1, 1]] ], { yaxis: { max: 1 } });


});


//this part is not working?
/*$(window).load(function () {
    Pizza.init({
        donut: false, // enable donut chart
        donut_inner_ratio: 0.4,   // between 0 and 1
        percent_offset: 35, // relative to radius
        stroke_color: '#333',
        stroke_width: 0,
        show_percent: true, // show or hide the percentage on the chart.
        animation_speed: 500,
        animation_type: 'elastic' // options: backin, backout, bounce, easein, easeinout, easeout, linear
    });
});
//this is the one that open the pie chart
$(window).load(function () {
    Pizza.init();
});*/