/**
 * Created by JaysonGCS on 8/7/16.
 */

$(document).ready(function () {

    var content_monitorsamplereport_data = '';
       // content_monitorsamplereport_data_nc = ''
  //  window._content_monitorsamplereport_data_pc = '';

    var data_overview2 = [{label: "FC ("+fully_compliant+"/"+total_compliant_organization+")", data: fully_compliant,color:"#4DA74D"},
        {label: "PC ("+partially_compliant+"/"+total_compliant_organization+")", data: partially_compliant,color:"#EDC240"},
        {label: "NC ("+not_compliant+"/"+total_compliant_organization+")", data: not_compliant,color:"#CB4B4B"},
        {label: "NA ("+not_applicable+"/"+total_compliant_organization+")", data: not_applicable,color:"grey"}];
    //monitoring
    function labelFormatter(label, series) {
        return "<div style='font-size:8pt; text-align:center; padding:2px; color:white;'>" + label + "<br/>" + Math.round(series.percent) + "%</div>";
    }

    $('#up-body-samplemonitor').hide();

    $('#monitoring_samplereport').click(function () {
        $('#up-body-monitor').hide();
        $('.monitoring').hide();

        $('#up-body-samplemonitor').fadeIn('slow');

        $.plot($("#pie_monitor_overview"), data_overview2, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 2 / 4,
                        formatter: labelFormatter,
                        background: {
                            opacity: 0.5,
                            color: "#000"
                        }
                    }
                }
            },
            legend: {
                show: true
            }
        });
    });


    $('#sidemenuonly>li').click(function () {
        if ($('#up_monitor').hasClass('active') == false) {
            $('#up-body-samplemonitor').hide();
            $('#monitoring_samplereport>a').removeClass('active');
            // alert("Hello! I am an alert box!");

        }
    });

    $('.dropdown-lvl1>.nav.navbar-nav>li').click(function () {
        $('#monitoring_samplereport>a').addClass('active');
    });

    /*
     lineitem_data_ic_pc+=
     '<tr class="warning"> ' +
     '<td>' + items[i]["Question"] +
     '<a href="#" ' +
     'title= "' + items[i]["Reference"] + '"' + 'data-content= "' + items[i]["Content of Reference"] + '"' +
     'data-toggle="popover" data-placement="top"data-trigger="hover" ><span class="fa fa-info-circle"></span> </a></td> ' +
     '<td>' + items[i]["Sub-category"] + '</td> ' +
     '<td>Partially Compliant</td> ' +
     '<td>' + items[i]["Notes"] + '</td> ' +
     '</tr> ';
     */

    function monitoring_report_template() {
        var textbox = '<textarea class="form-control" rows="3" placeholder="Type your corrective action here."></textarea>';
        return '<tr class="warning"> ' +
            '<td>' + items[i]["Question"] +
            '<a href="#" ' +
            'title= "' + items[i]["Reference"] + '"' + 'data-content= "' + items[i]["Content of Reference"] + '"' +
            'data-toggle="popover" data-placement="top"data-trigger="hover" ><span class="fa fa-info-circle"></span> </a></td> ' +
            '<td>' + items[i]["Categorization"] + '</td> ' +
            '<td>' + items[i]["Sub-category"] + '</td> ' +
            '<td>Partially Compliant</td> ' +
            '<td>' + items[i]["Notes"] + '</td> ' +
            '<td>' + textbox + '</td> ' +
            '<td>' + +'</td> ' +
            '<td>' + +'</td> ' +

            '</tr> ';
    }

  /*  _content_monitorsamplereport_data_pc =
        '<h5>Partially Compliant Items</h5><div class="table-responsive">' +
        '<table style="text-align: left;" class="table table-condensed"> ' +
        '<thead> <tr> ' +
        '<th>ID</th> ' +
        '<th>Category</th> ' +
        '<th>Answer</th> ' +
        '<th>Notes</th>' +
        '<th>Person-in-charge</th>' +
        '<th>Corrective Action to Take</th>' +
        ' </tr> </thead> ' +
        '<tbody> ' +

        _monitor_lineitem_data_pc +

        '</tbody> </table></div>';*/

    content_monitorsamplereport_data =
    /*    '<h5>Partially Compliant Items</h5><div >' +
        '<table style="text-align: left;" class="table table-condensed"> ' +
        '<thead> <tr> ' +
        '<th>Question</th> ' +
        '<th>Category</th> ' +
        '<th>Sub-category</th> ' +
        '<th>Answer</th> ' +
        '<th>Notes</th>' +
        '<th>Corrective Action to Take</th>' +
        '<th>Person-in-charge</th>' +
        '<th>Deadline</th>' +
        ' </tr> </thead> ' +
        '<tbody> ' +*/
        '<h5>Item List</h5><div class="table-responsive">' +
        '<table id="table_monitor" style="text-align: left;" class="table table-bordered table-condensed"> ' +
        '<thead> <tr> ' +
        '<th>Question</th> ' +
        '<th>Notes</th>' +
        '<th> </th>' +
        '<th> </th>' +
        ' </tr> </thead> ' +
        '<tbody> ' +
        monitor_lineitem_data_pc + monitor_lineitem_data_nc

        '</tbody> </table></div>';

 //   content_monitorsamplereport_data_nc =
    /*    '<h5>Not Compliant Items</h5>' +
        '<table style="text-align: left;" class="table table-condensed"> ' +
        '<thead> <tr> ' +
        '<th>Question</th> ' +
        '<th>Category</th> ' +
        '<th>Sub-category</th> ' +
        '<th>Answer</th> ' +
        '<th>Notes</th>' +
        '<th>Corrective Action to Take</th>' +
        '<th>Person-in-charge</th>' +
        '<th>Deadline</th>' +
        ' </tr> </thead> ' +
        '<tbody> ' +*/

      /*  '<h5>Not Compliant Items</h5><div class="table-responsive">' +
        '<table style="text-align: left;" class="table table-condensed"> ' +
        '<thead> <tr> ' +
        '<th>ID</th> ' +
        '<th>Category</th> ' +
        '<th>Answer</th> ' +
        '<th>Notes</th>' +
        '<th> </th>' +
        '<th> </th>' +
        ' </tr> </thead> ' +
        '<tbody> ' +

        monitor_lineitem_data_nc +

        '</tbody> </table>';*/

    $('#datamonitor').append(content_monitorsamplereport_data);
  //  $('#datamonitor_nc').append(content_monitorsamplereport_data_nc);
  //  $('#_datamonitor_pc').append(_content_monitorsamplereport_data_pc);

    for(var i=0;i<monitoring_date.length;i++){
        $('#'+monitoring_date[i]).datepicker({
            format: "dd/mm/yyyy"
        });
    }

  /*  $('#monitor_date_3').datepicker({
        format: "dd/mm/yyyy"
    });*/


    $(document).ready(function () {
        $(".monitoring_filter").select2({
            placeholder: "Filter",
            closeOnSelect: false,
            tokenSeparators: [',', ' ']
        });

        $('#monitoring_filter').on("select2:select", function (e) {
            //   alert($('#monitoring_filter').val());
            $('#table_monitor>tbody tr').hide();
            var filter_items = $('#monitoring_filter').val();
            // var filter_items_tag = '';
            for (var i = 0; i < filter_items.length; i++) {

                // filter_items_tag +="."+ filter_items[i];

                /*   if (filter_items[i] == "ic") {
                 $('#table_monitor .ic').show();
                 }
                 if (filter_items[i] == "trm") {
                 $('#table_monitor .trm').show();

                 }
                 if (filter_items[i] == "bcm") {
                 $('#table_monitor .bcm').show();

                 }
                 if (filter_items[i] == "out") {
                 $('#table_monitor .out').show();

                 }*/

                $('#table_monitor .'+filter_items[i]).show();
            }
        });
        $('#monitoring_filter').on("select2:unselect", function (e) {
            //alert($('#monitoring_filter').val());
            if ($('#monitoring_filter').val() == null) {
                $('#table_monitor>tbody tr').show();
            }
            else {
                $('#table_monitor>tbody tr').hide();
                var filter_items = $('#monitoring_filter').val();
                for (var i = 0; i < filter_items.length; i++) {
                    $('#table_monitor .'+filter_items[i]).show();
                }
            }
        });

    });
});

