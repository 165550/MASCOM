/**
 * Created by JaysonGCS on 11/7/16.
 */
$(document).ready(function () {

    $('#shortcut_userpanel').hide();

    function myFunction() {
        var email,pass, text;

        // Get the value of the input field with id="numb"
        email = document.getElementById("exampleInputEmail2").value;
        pass = document.getElementById("exampleInputPassword2").value;

        // If x is Not a Number or less than one or greater than 10
        if ( email=="admin@admin"&&pass =="admin") {
            $('#shortcut_userpanel').show();
            $('#login_text').hide();
            $('#login_login').hide();
            $('#shortcut_userpanel').show();
            location.href="/userpanel";
            $("form").submit();
        }
        else {

            text = "Input not valid!";
        }
        
      //  document.getElementById("#login_warning").innerHTML = text;
        $("#login_warning").text(text);
    }
    $("form").submit(function(ev){ev.preventDefault();});

    $('#login_submit').click(function(){
        myFunction();
    });
});
