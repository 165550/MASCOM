/**
 * Created by JaysonGCS on 4/7/16.
 */

var json_profiling = {
    "items": [
        {
            "No.": "PQ1",
            "Question": "Is your institution incorporated overseas for the purposes of reporting to the Board of Directors?",
            "Category": "Overall",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 1
        },
        {
            "No.": "PQ2",
            "Question": "Is your institution�s internal audit function located overseas?",
            "Category": "Overall",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 1
        },
        {
            "No.": "PQ3",
            "Question": "Does your institution provide any payment card services to your customers?",
            "Category": "Technology Risk",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 19
        },
        {
            "No.": "PQ4",
            "Question": "Does your institution provide any customer-facing services over the Internet or other networks?",
            "Category": "Technology Risk",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 45
        },
        {
            "No.": "PQ5",
            "Question": "Does your institution utilize Storage Area Networks (SAN) for its data storage sub-system architecture, utilizing internet connection with the production server?",
            "Category": "Technology Risk",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 3
        },
        {
            "No.": "PQ6",
            "Question": "Is this Assessment Instance / your Institution concerned with Data Center Risk Management Framework and Processes?",
            "Category": "Technology Risk",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 17
        },
        {
            "No.": "PQ7",
            "Question": "Is this Assessment Instance / your Institution concerned with IT regulations surrounding protection against IT attacks?",
            "Category": "Technology Risk",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 13
        },
        {
            "No.": "PQ8",
            "Question": "Is this Assessment Instance / your Institution concerned with IT regulations surrounding testing of IT systems?",
            "Category": "Technology Risk",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 15
        },
        {
            "No.": "PQ9",
            "Question": "Does your institution currently outsource any IT functions to outside your institution?",
            "Category": "Outsourcing",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 41
        },
        {
            "No.": "PQ10",
            "Question": "Does your institution�s Board of Directors have a committee delegated to be responsible for Outsourcing Risk Management at your institution?",
            "Category": "Outsourcing",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 1
        },
        {
            "No.": "PQ11",
            "Question": "Does your institution currently outsource its Internal Audit function?",
            "Category": "Outsourcing",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 2
        },
        {
            "No.": "PQ12",
            "Question": "Does your institution currently outsource any function to service providers residing outside Singapore?",
            "Category": "Outsourcing",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 7
        },
        {
            "No.": "PQ13",
            "Question": "Does your institution currently outsource to service providers within your institution�s group?",
            "Category": "Outsourcing",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 1
        },
        {
            "No.": "PQ14",
            "Question": "Does your institution�s branches or any corporations in association, currently outsource any of its IT functions?",
            "Category": "Outsourcing",
            "Options (Implication)": "1) Yes\n2) No (\"Not Applicable\")",
            "Number of Concerned Line items": 1
        }
    ]
};

var content_profiling_overall = '', content_profiling_trm = '', content_profiling_outsourcing = '';

window.profiling_id = [];

$(document).ready(function () {
   // $('#up_assessment').on('click', function () {
        $.get('../genProfiling', function (items) {
            var content = '';

            content_profiling_overall = '<div role="tabpanel" class="tab-pane active info" id="overall">';
            content_profiling_trm = '<div role="tabpanel" class="tab-pane info" id="trm">';
            content_profiling_outsourcing = '<div role="tabpanel" class="tab-pane info" id="outsourcing">';

            function profiling_question_template() {
                return '<div class="panel panel-primary"> ' +
                    '<div class="panel-heading"> <h3 class="panel-title ">' + items[i]["Question"] + '</h3></div>' +
                    '<div class="panel-body two-col"> ' +
                    '<div class="row"> ' +
                    '<div class="col-md-6"> ' +
                    '<div class="well well-sm"> ' +
                    '<div class="radio"> <label> ' +
                    '<input type="radio"name="' + items[i]["Index"] + '" value="Yes">Yes </label> </div> </div> </div> ' +
                    '<div class="col-md-6">' +
                    ' <div class="well well-sm"> ' +
                    '<div class="radio"> <label> ' +
                    '<input type="radio" name="' + items[i]["Index"] + '" value="No">No ("Not Applicable") </label> </div> ' +
                    '</div> </div> </div> </div></div>';
            }


            for (var i = 0; i < items.length; i++) {
                if(items[i]["Profiling"]=="TRUE") {
                    profiling_id.push(items[i]["Index"]);
                    if (items[i]["Categorization"] == 'Overall') {
                        content_profiling_overall += profiling_question_template();

                    }
                    else if (items[i]["Categorization"] == 'Technology Risk') {
                        content_profiling_trm += profiling_question_template();
                    }
                    else if (items[i]["Categorization"] == 'Outsourcing') {
                        content_profiling_outsourcing += profiling_question_template();
                    }
                }
            }

            content_profiling_overall += '</div>';
            content_profiling_trm += '</div>';
            content_profiling_outsourcing += '</div>';

            content = content_profiling_overall + content_profiling_trm + content_profiling_outsourcing;
            $('#profiling_content').append(content);

            $('#profiling_selectall_ic').click(function () {
                $('#internalcontrol input[type="checkbox"]').prop('checked', true);
            });
            $('#profiling_selectall_trm').click(function () {
                $('#techrisk2 input[type="checkbox"]').prop('checked', true);
            });
            $('#profiling_selectall_bcm').click(function () {
                $('#bcm input[type="checkbox"]').prop('checked', true);
            });
            $('#profiling_selectall_out').click(function () {
                $('#outsourcing2 input[type="checkbox"]').prop('checked', true);
            });


            //test some new func for tracking selected val
            $('#profiling_content input').on("change", function () {
                var test = '';
                for (var ttt = 0; ttt < profiling_id.length; ttt++) {
                    test += $('input[name="'+profiling_id[ttt]+'"]:checked').val();
                    //alert(profiling_id[ttt]);
                }
                //alert("something clicked: " + $('input[name=PQ1]:checked').val());


                //this is very useful**************
                //alert($(this).attr("name")+': '+$(this).val());
            });



            //end
        });
  //  })
});
