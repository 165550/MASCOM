var title = "", subtitle = '';

window.assessment_id = [];
window.assessment_ReportDate = '';
window.assessment_Assessor = '';

$(document).ready(function () {

    $('#assessment-btn-profiling-1').on('click', function () {
        if (flag_profiling_assessment == true) {
            console.log("After Next Button");
            var content = '', content_dropdown = '';
            
            var answerArray = [];
            for (var num = 0; num < profiling_id.length; num++) {
                var identifier = profiling_id[num];
                if ($('input[name=' + identifier + ']:checked')) {
                    answerArray[num] = $('input[name=' + identifier + ']:checked').val();
                } else {
                    answerArray[num] = "";
                }
            }
            $.post('./genReport', {
                "reportAssessor": $("#reportprofile_assessor").val(),
                "reportDate": $("#reportprofile_date").val(),
                "currDate": new Date(),
                "profilingIDs": profiling_id,
                "profilingAnswer": answerArray
            }, function (data) {
                assessment_ReportDate = data.ReportDate;
                assessment_Assessor = data.Assessor;
                var items = data.Questions;
                console.log("Here");
                console.log(items);


                function content_cat_subcat() {
                    var temp_content = '';
                    if (items[i]["Answer"] == "Not Applicable") {
                        temp_content = 'checked="checked"';
                    }

                    assessment_id.push(items[i]["Index"]);
                    return ' <div class="panel panel-primary"> <div class="panel-heading"> ' +
                        '<h3 class="panel-title ">' + items[i]["Question"] +
                        '<a class="popover_assessment" href="#" title="' + items[i]["Reference"] + '"' +
                        'data-toggle="popover"data-placement="top"data-trigger="hover"' +
                        'data-content="' + items[i]["ContentofReference"] + '"> <span class="fa fa-info-circle"></span> </a> </h3> </div>' +
                        '<div class="panel-body two-col"> <div class="row"> ' +
                        '<div class="col-md-3 col-sm-6"> <div class="well well-sm"> <div class="radio"> ' +
                        '<label> <input type="radio" name="' + items[i]["Index"] + '" value="FC">' +
                        'Fully Compliant </label> </div> </div> </div>' +
                        ' <div class="col-md-3 col-sm-6"> <div class="well well-sm"> <div class="radio"> ' +
                        '<label> <input type="radio" name="' + items[i]["Index"] + '" value="PC">' +
                        'Partially Compliant </label> </div> </div> </div> ' +
                        '<div class="col-md-3 col-sm-6"> <div class="well well-sm"> <div class="radio"> ' +
                        '<label> <input type="radio" name="' + items[i]["Index"] + '" value="NC">' +
                        'Non-compliant </label> </div> </div> </div> ' +
                        '<div class="col-md-3 col-sm-6"> <div class="well well-sm"> <div class="radio"> ' +
                        '<label> <input type="radio" name="' + items[i]["Index"] + '" value="NA" ' + temp_content + '>' +
                        'N/A (Not Applicable) </label> </div> </div> </div> </div>' +
                        '<textarea id="' + 'assessment_note_' + items[i]["Index"] + '" class="form-control" rows="3" placeholder="Type your note here."></textarea>' +
                        '<br><p>Upload Documents: </p><input  type="file" multiple id="assessment_upload_' + items[i]["Index"] + '">' +
                        ' </div> </div>';
                }

                //var items = json_assessment.items;

//test for scalability and maintainability
                var category_main = [], category_sub = [], content_arr = [], id_category = [], id_subcategory = [];
                var y = 0;
                var f_repeated = false, f_repeated_sub = false;
                for (var x = 0; x < (items.length); x++) {
                    if (y == 0) {
                        category_main[0] = items[x]["Categorization"];
                        //category_sub[0].push(items[x]["Subcategory"]);
                        id_category[0] = items[x]["CategorizationKey"];
                        y++
                    }
                    else {
                        f_repeated = false;
                        for (var z = 0; z < category_main.length; z++) {
                            if (category_main[z] == items[x]["Categorization"]) {
                                f_repeated = true;
                                f_repeated_sub = true;
                                /*   for (var a = 0; a < category_sub.length; a++) {
                                 if (category_sub[z][a] == items[x]["Subcategory"]) {
                                 f_repeated_sub = true;
                                 }
                                 }
                                 if (f_repeated_sub == false) {
                                 category_sub[z].push(items[x]["Subcategory"]);
                                 }*/
                            }
                        }
                        if (f_repeated == false) {
                            category_main[y] = items[x]["Categorization"];
                            id_category[y] = items[x]["CategorizationKey"];
                            y++;
                        }
                    }


                }
                /*  for (var c = 0; c < 4; c++) {
                 // for (var b = 0; b<category_main.length; b++) {
                 for (var b = 0; b < category_sub.length; b++) {
                 //alert(category_main[b]);
                 //  alert(category_sub[c][b]);
                 }
                 }*/

//end phase 1
                for (y = 0; y < category_main.length; y++) {
                    category_sub.push([]);
                    id_subcategory.push([]);
                }

                for (x = 0; x < (items.length); x++) {
                    for (y = 0; y < category_main.length; y++) {
                        if (category_main[y] == items[x]["Categorization"]) {
                            f_repeated_sub = false;
                            for (z = 0; z < category_sub[y].length; z++) {
                                if (category_sub[y][z] == items[x]["Subcategory"]) {
                                    f_repeated_sub = true;
                                }
                            }
                            if (f_repeated_sub == false) {
                                category_sub[y].push(items[x]["Subcategory"]);
                                id_subcategory[y].push(items[x]["SubcategoryKey"]);
                            }
                        }
                    }
                }
                /*  for (x = 0; x < category_main.length; x++) {
                 for (y = 0; y < category_sub[x].length; y++) {
                 alert(category_main[x] + " - " +y+" " +category_sub[x][y]);
                 }
                 }*/

                /* for(x=0;x<category_main.length;x++){
                 alert(category_main[x]);
                 }*/

                //end phase 2 - category and Subcategory

                //initialize 3d array for content
                for (x = 0; x < category_main.length; x++) {
                    content_arr.push([]);
                    for (y = 0; y < category_sub[x].length; y++) {
                        content_arr[x].push([]);
                    }
                }

                //by using push to the 3rd dimension, we can trace the number of items, this can't be done in +=
                for (var i = 0; i < (items.length); i++) {
                    for (x = 0; x < category_main.length; x++) {
                        if (category_main[x] == items[i]["Categorization"]) {
                            for (y = 0; y < category_sub[x].length; y++) {
                                if (category_sub[x][y] == items[i]["Subcategory"]) {
                                    content_arr[x][y].push(content_cat_subcat());
                                    // alert(x+' '+y+"---"+content_arr[x][y]);
                                }
                            }
                            //alert(items[i]["Categorization"] + ' ' + category_main[x]);
                        }
                    }
                }
                //alert(content_arr[2][1][0]);


                for (x = 0; x < category_main.length; x++) {
                    title = category_main[x];
                    for (y = 0; y < category_sub[x].length; y++) {
                        subtitle = category_sub[x][y];
                        content += '<div role="tabpanel" ';
                        if (x == 0 && y == 0) {
                            content += 'class="tab-pane active info" ';
                        }
                        else {
                            content += 'class="tab-pane info" ';
                        }
                        content += 'id="assessment_' + id_category[x] + '_' + id_subcategory[x][y] + '"> ' +
                            '<div class="info">' +
                            '<h5>' + title + '</h5> ' +
                            '<p>' + subtitle + '</p></div>';
                        for (z = 0; z < content_arr[x][y].length; z++) {
                            content += content_arr[x][y][z];
                        }
                        content += '</div>';

                        //alert(id_category[x] + '_' + id_subcategory[x][y]);
                    }
                }
                //end phase 3 (end)

//dropdown menu


                for (x = 0; x < category_main.length; x++) {
                    content_dropdown += '<li id="tab_' + id_category[x] + '_box" role="presentation" ';
                    if (x == 0) {
                        content_dropdown += 'class="dropdown active">';
                    }
                    else {
                        content_dropdown += 'class="dropdown">';
                    }
                    content_dropdown += '<a class="tab_category" id="tab_' + id_category[x] + '"href="#" role="tab"data-toggle="tab">' + category_main[x] + '<span' +
                        'class="caret"></span></a>' +
                        '<ul id="assessment_list_' + id_category[x] + '"' +
                        'class="nav nav-tabs materialtabs dropdown-content"role="tablist"> ';

                    for (y = 0; y < category_sub[x].length; y++) {
                        if (x == 0 && y == 0) {
                            content_dropdown += '<li class="active">';
                        }
                        else {
                            content_dropdown += '<li>';
                        }
                        content_dropdown += '<a href="#assessment_' + id_category[x] + '_' + id_subcategory[x][y] +
                            '"aria-controls="assessment_' + id_category[x] + '_' + id_subcategory[x][y] + '"role="tab"' +
                            'data-toggle="tab">' + category_sub[x][y] + '</a> </li> ';
                    }
                    content_dropdown += '</ul></li>';
                }

                /*   content_dropdown = '<li id="tab-ic-box" role="presentation" class="dropdown active"> ' +
                 '<a id="tab-ic" href="#" role="tab"data-toggle="tab">Internal Controls <span' +
                 'class="caret"></span></a> ' +
                 '<ul id="assessment-list-ic"' +
                 'class="nav nav-tabs materialtabs dropdown-content"role="tablist"> ' +
                 '<li class="active"><a href="#assessment_IC_rar"aria-controls="assessment_IC_rar"role="tab"' +
                 'data-toggle="tab">A) Roles and Responsibilities</a> </li> ' +
                 '<li> <a href="#assessment_IC_aar"aria-controls="assessment_IC_aar"role="tab" ' +
                 'data-toggle="tab">B) Assessment and Reporting</a> </li> ' +
                 '</ul> </li>';*/

                $('#assessment-dropdownmenu').html(content_dropdown);

                //end of assessment dropdown menu

                $('#assessment-content').html(content);

                $('.popover_assessment').popover();


                //here onwards is the assessment dropdown menu highlight effect
                $('.tab_category').click(function (event) {
                    $('.nav-tabs.materialtabs >li').removeClass("active");
                    $(this).parent().find("a:eq(1)").click();
                });


                $('.materialtabs.dropdown-content>li>a').click(function (event) {
                    $('.nav-tabs.materialtabs >li').removeClass("active");
                    $(this).parent().parent().parent().addClass("active");
                });
            })

        }
    })

})
;