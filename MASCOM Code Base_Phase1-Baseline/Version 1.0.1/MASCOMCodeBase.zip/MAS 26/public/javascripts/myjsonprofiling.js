var content_profiling_overall = '', content_profiling_trm = '', content_profiling_outsourcing = '';

window.profiling_id = [];

/*Non Scalable Profiling Page generation code*/
$(document).ready(function () {
    /*  Function: On calling of User Panel page, Pull Profiling Questions from Database and generate on frontend
        Inputs: None
        Outputs:    1) Profiling Questions frontend page content
                    2) profiling_id is the array of IDs of the Profiling Questions */
    $.get('../genProfiling', function (items) {
        var content = '';

        content_profiling_overall = '<div role="tabpanel" class="tab-pane active info" id="overall">';
        content_profiling_trm = '<div role="tabpanel" class="tab-pane info" id="trm">';
        content_profiling_outsourcing = '<div role="tabpanel" class="tab-pane info" id="outsourcing">';

        /*Content template for generating frontend of content of Profiling Page*/
        function profiling_question_template() {
            return '<div class="panel panel-primary"> ' +
                '<div class="panel-heading"> <h3 class="panel-title ">' + items[i]["Question"] + '</h3></div>' +
                '<div class="panel-body two-col"> ' +
                '<div class="row"> ' +
                '<div class="col-md-6"> ' +
                '<div class="well well-sm"> ' +
                '<div class="radio"> <label> ' +
                '<input type="radio"name="' + items[i]["Index"] + '" value="Yes">Yes </label> </div> </div> </div> ' +
                '<div class="col-md-6">' +
                ' <div class="well well-sm"> ' +
                '<div class="radio"> <label> ' +
                '<input type="radio" name="' + items[i]["Index"] + '" value="No">No ("Not Applicable") </label> </div> ' +
                '</div> </div> </div> </div></div>';
        }

        /*loop through all items and assign to its respective category*/
        for (var i = 0; i < items.length; i++) {
            if (items[i]["Profiling"] == "TRUE") {
                profiling_id.push(items[i]["Index"]);
                if (items[i]["Categorization"] == 'Overall') {
                    content_profiling_overall += profiling_question_template();
                }
                else if (items[i]["Categorization"] == 'Technology Risk') {
                    content_profiling_trm += profiling_question_template();
                }
                else if (items[i]["Categorization"] == 'Outsourcing') {
                    content_profiling_outsourcing += profiling_question_template();
                }
            }
        }
        content_profiling_overall += '</div>';
        content_profiling_trm += '</div>';
        content_profiling_outsourcing += '</div>';

        content = content_profiling_overall + content_profiling_trm + content_profiling_outsourcing;
        $('#profiling_content').append(content);

        /*"Select All" function for section 2*/
        $('#profiling_selectall_ic').click(function () {
            $('#internalcontrol input[type="checkbox"]').prop('checked', true);
        });
        $('#profiling_selectall_trm').click(function () {
            $('#techrisk2 input[type="checkbox"]').prop('checked', true);
        });
        $('#profiling_selectall_bcm').click(function () {
            $('#bcm input[type="checkbox"]').prop('checked', true);
        });
        $('#profiling_selectall_out').click(function () {
            $('#outsourcing2 input[type="checkbox"]').prop('checked', true);
        });
        
        //For tracking selected val
        $('#profiling_content input').on("change", function () {
            var test = '';
            for (var ttt = 0; ttt < profiling_id.length; ttt++) {
                test += $('input[name="' + profiling_id[ttt] + '"]:checked').val();
            }
            //this is very useful**************
            //the alert display the selected answer
            //alert($(this).attr("name")+': '+$(this).val());
        });
    });
});
