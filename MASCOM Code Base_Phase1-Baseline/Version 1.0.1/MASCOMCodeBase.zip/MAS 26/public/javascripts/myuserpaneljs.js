/**
 * Created by JaysonGCS on 27/6/16.
 */

/*Side menu effect*/
$(function () {
    $('.navbar-toggle#sidemenu').click(function () {
        $('.navbar-nav').toggleClass('slide-in');
        $('.side-body').toggleClass('body-slide-in');
        $('#search').removeClass('in').addClass('collapse').slideUp(200);

    });

    $('.navbar-nav#sidemenuonly>li').click(function (e) {
        e.preventDefault();
        $(this).parent().find('li').removeClass('active');
        $(this).addClass('active');
    });


    // Remove menu for searching
    /*currently not in use*/
    $('#search-trigger').click(function () {
        $('.navbar-nav').removeClass('slide-in');
        $('.side-body').removeClass('body-slide-in');

    });
});