/**
 * Created by JaysonGCS on 11/7/16.
 */

/*simple login validation from landing page to user panel*/
$(document).ready(function () {

    $('#shortcut_userpanel').hide();

    /*simple function to validate user and navigate to user panel if verified*/
    function myFunction() {
        var email,pass, text;

        email = document.getElementById("exampleInputEmail2").value;
        pass = document.getElementById("exampleInputPassword2").value;

        if ( email=="admin@admin"&&pass =="admin") {
            $('#shortcut_userpanel').show();
            $('#login_text').hide();
            $('#login_login').hide();
            $('#shortcut_userpanel').show();
            location.href="/userpanel";
            $("form").submit();
        }
        else {

            text = "Input not valid!";
        }

        $("#login_warning").text(text);
    }
    $("form").submit(function(ev){ev.preventDefault();});

    /*when login clicked, trigger myFunction for validation*/
    $('#login_submit').click(function(){
        myFunction();
    });
});