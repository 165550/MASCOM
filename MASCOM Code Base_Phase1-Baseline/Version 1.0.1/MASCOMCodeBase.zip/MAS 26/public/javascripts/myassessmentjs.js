window.flag_profiling_assessment = false;

/* Function: Collects all Inputs and calls a POST to save Assessment Answers into Database
    Inputs: Takes in:
            1) IDs of Assessment Generated when Creating the Report in Profiling Page
            2) Answers and Notes Provided by the User
            3) Report Date and Assessor Provded by the USer
     Outputs: None*/
function saveAnswers(ansArray, notesArray) {
    $.post('./updateReport', {
        "assessmentIDs": assessment_id,
        "assessmentAns": ansArray,
        "assessmentNotes": notesArray,
        "reportDate": assessment_ReportDate,
        "reportAssessor": assessment_Assessor
    });
}

$(document).ready(function () {
    //Hide profiling intro and assessment page when load user panel
    $('#up-body-assessment-profilingintro').hide();
    $('#up-body-assessment-assessment').hide();

    //After side menu at user panel has been clicked, hide profiling intro and assessment page
    $('.navbar-nav#sidemenuonly>li').click(function () {
        $('#up-body-assessment-profilingintro').hide();
        $('#up-body-assessment-assessment').hide();
    });
    /*Function: Validation of Completeness of Profiling Section
        Inputs: profiling_id generated when creating the Profiling Page
        Outputs:    1) If true, proceed to next section (Assessment Introduction Page)
                    2) IF false, popup warning */
    $('#assessment-btn-profiling-1').click(function () {
        var flag = '';
        for (var i = 0; i < profiling_id.length; i++) {
            if ($('[name="' + profiling_id[i] + '"]').is(':checked') == true) {
                flag = true;
            }
            else {
                flag = false;
                break;
            }
        }

        if (flag == true) {
            $('#up-body-assessment-profiling').hide();
            $('#up-body-assessment-profilingintro').fadeIn('slow');
            flag_profiling_assessment = true;
        }
        else {
            alert("Profiling incomplete!");
            flag_profiling_assessment = false;

        }
    });

    //After clicked, proceed to assessment page
    $('#assessment-btn-profiling-2').click(function () {
        $('#up-body-assessment-profilingintro').hide();
        $('#up-body-assessment-assessment').fadeIn('slow');

    });
    //Back button at profiling intro page
    $('#assessment-btn-profiling-2-back').click(function () {
        $('#up-body-assessment-profilingintro').hide();
        $('#up-body-assessment-profiling').fadeIn('slow');

    });
    //Start button at profiling intro page
    $('#assessment-btn-profiling-2-startassessment').click(function () {
        $('#up-body-assessment-profilingintro').hide();
        $('#up-body-assessment-assessment').fadeIn('slow');

    });
    //Back button at assessment page
    $('#assessment-btn-profiling-assesssment-back').click(function () {
        $('#up-body-assessment-assessment').hide();
        $('#up-body-assessment-profilingintro').fadeIn('slow');

    });
    /*Function: Validation of Completeness of Assessment (for Submit button #1 and #2 in Assessment Page)
        Inputs: assessment_id generated when pulling questions from database to create Report
        Outputs:    1) If completed, call saveAnswer function to POST to database, jump to Report Page
                    2) IF not completed, popup warning */
    //Submit Button 1
    $('#assessment-btn-assessment-submit-1').click(function () {
        var flag = '';
        var answersArray = [];
        var notes = [];
        for (var i = 0; i < assessment_id.length; i++) {
            if ($('[name="' + assessment_id[i] + '"]').is(':checked') == true) {
                flag = true;
            }
            else {
                flag = false;
                break;
            }
            answersArray[i] = $('[name=' + assessment_id[i] + ']:checked').val();
            notes[i] = $('[id=assessment_note_' + assessment_id[i]).val();
        }

        if (flag == true) {
            $('#up-body-assessment-assessment').hide();
            $('#up_report').click();
            saveAnswers(answersArray, notes);
        }
        else {
            alert("Assessment incomplete!");
        }
    });
    //Submit Button 2
    $('#assessment-btn-assessment-submit-2').click(function () {
        var flag = '';
        var answersArray = [];
        var notes = [];
        for (var i = 0; i < assessment_id.length; i++) {
            if ($('[name="' + assessment_id[i] + '"]').is(':checked') == true) {
                flag = true;
            }
            else {
                flag = false;
                break;
            }
            answersArray[i] = $('[name=' + assessment_id[i] + ']:checked').val();
            notes[i] = $('[id=assessment_note_' + assessment_id[i]).val();
        }

        if (flag == true) {
            $('#up-body-assessment-assessment').hide();
            $('#up_report').click();
            saveAnswers(answersArray, notes);
        }
        else {
            alert("Assessment incomplete!");
        }
    });
});