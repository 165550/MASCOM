/**
 * Created by JaysonGCS on 30/6/16.
 */
$(function () {
    //initialization for popover function that doesn't require triggering to be activated
    $(document).ready(function () {
        $('[data-toggle="popover"]').popover();
    });
    $(document).ready(function () {
        $('[data-toggle="popover2"]').popover();
    });

    $('#up-body-assessment-profiling').hide();
    $('#up-body-reports').hide();
    $('#up-body-monitor').hide();


    $('.navbar-nav#sidemenuonly>li').click(function (e) {
        e.preventDefault();
        if ($(this).parent().find('#up_sum').hasClass('active')) {
            $('#up-body-summary').fadeIn('slow');
        }
        else {
            $('#up-body-summary').hide();
        }
        if ($(this).parent().find('#up_assessment').hasClass('active')) {
            $('#up-body-assessment-profiling').fadeIn('slow');
        }
        else {
            $('#up-body-assessment-profiling').hide();
        }

    });
})
;