/*Scalable code for generating assessment questions*/
var title = "", subtitle = '';

window.assessment_id = [];
window.assessment_ReportDate = '';
window.assessment_Assessor = '';

$(document).ready(function () {
    /*  Function: On click of "Next" button at profiling page, trigger the following actions:
            1) POST Profiling Answers to Database and generate Report on Database
            2) GET Report from Database
            3)Generate frontend html code from the Report
        Inputs: 1) flag_profiling_assessment from validation of completeness of Profiling Section
                2) profiling_id is an array of profiling ID when generating Profiling Page
                3) User Inputs: Array of Profiling Answers, Report Date and Assessor Name
        Outputs: 1) frontend page of Assessment Questions
                 2) Generation of Report on Database
                 3) assessment_id, assessment_ReportDate and assessment_Assessor to track Report instance */
    $('#assessment-btn-profiling-1').on('click', function () {
        //if profiling assessment has been completed, flag will be true. The flag is a global variable from profiling javascript file
        if (flag_profiling_assessment == true) {
            var content = '', content_dropdown = '';
            
            var answerArray = [];
            //Receives the Answers of Profiling Questions
            for (var num = 0; num < profiling_id.length; num++) {
                var identifier = profiling_id[num];
                if ($('input[name=' + identifier + ']:checked')) {
                    answerArray[num] = $('input[name=' + identifier + ']:checked').val();
                } else {
                    answerArray[num] = "";
                }
            }
            //Step 1 and 2: Database Operation Call to Create the Report, returns the Report for frontend generation
            $.post('./genReport', {
                "reportAssessor": $("#reportprofile_assessor").val(),
                "reportDate": $("#reportprofile_date").val(),
                "currDate": new Date(),
                "profilingIDs": profiling_id,
                "profilingAnswer": answerArray
            }, function (data) {
                //Step 3: Create the frontend code from the Report
                assessment_ReportDate = data.ReportDate;
                assessment_Assessor = data.Assessor;
                var items = data.Questions;

                //Content template for assessment question
                function content_cat_subcat() {
                    var temp_content = '';
                    if (items[i]["Answer"] == "Not Applicable") {
                        temp_content = 'checked="checked"';
                    }

                    assessment_id.push(items[i]["Index"]);
                    return ' <div class="panel panel-primary"> <div class="panel-heading"> ' +
                        '<h3 class="panel-title ">' + items[i]["Question"] +
                        '<a class="popover_assessment" href="#" title="' + items[i]["Reference"] + '"' +
                        'data-toggle="popover"data-placement="top"data-trigger="hover"' +
                        'data-content="' + items[i]["ContentofReference"] + '"> <span class="fa fa-info-circle"></span> </a> </h3> </div>' +
                        '<div class="panel-body two-col"> <div class="row"> ' +
                        '<div class="col-md-3 col-sm-6"> <div class="well well-sm"> <div class="radio"> ' +
                        '<label> <input type="radio" name="' + items[i]["Index"] + '" value="FC">' +
                        'Fully Compliant </label> </div> </div> </div>' +
                        ' <div class="col-md-3 col-sm-6"> <div class="well well-sm"> <div class="radio"> ' +
                        '<label> <input type="radio" name="' + items[i]["Index"] + '" value="PC">' +
                        'Partially Compliant </label> </div> </div> </div> ' +
                        '<div class="col-md-3 col-sm-6"> <div class="well well-sm"> <div class="radio"> ' +
                        '<label> <input type="radio" name="' + items[i]["Index"] + '" value="NC">' +
                        'Non-compliant </label> </div> </div> </div> ' +
                        '<div class="col-md-3 col-sm-6"> <div class="well well-sm"> <div class="radio"> ' +
                        '<label> <input type="radio" name="' + items[i]["Index"] + '" value="NA" ' + temp_content + '>' +
                        'N/A (Not Applicable) </label> </div> </div> </div> </div>' +
                        '<textarea id="' + 'assessment_note_' + items[i]["Index"] + '" class="form-control" rows="3" placeholder="Type your note here."></textarea>' +
                        '<br><p>Upload Documents: </p><input  type="file" multiple id="assessment_upload_' + items[i]["Index"] + '">' +
                        ' </div> </div>';
                }

//Implementation for scalability and maintainability
                var category_main = [], category_sub = [], content_arr = [], id_category = [], id_subcategory = [];
                var y = 0;
                var f_repeated = false, f_repeated_sub = false;
                for (var x = 0; x < (items.length); x++) {
                    if (y == 0) {
                        category_main[0] = items[x]["Categorization"];
                        id_category[0] = items[x]["CategorizationKey"];
                        y++
                    }
                    else {
                        f_repeated = false;
                        for (var z = 0; z < category_main.length; z++) {
                            if (category_main[z] == items[x]["Categorization"]) {
                                f_repeated = true;
                                f_repeated_sub = true;
                            }
                        }
                        if (f_repeated == false) {
                            category_main[y] = items[x]["Categorization"];
                            id_category[y] = items[x]["CategorizationKey"];
                            y++;
                        }
                    }
                }
//end phase 1
                for (y = 0; y < category_main.length; y++) {
                    category_sub.push([]);
                    id_subcategory.push([]);
                }

                for (x = 0; x < (items.length); x++) {
                    for (y = 0; y < category_main.length; y++) {
                        if (category_main[y] == items[x]["Categorization"]) {
                            f_repeated_sub = false;
                            for (z = 0; z < category_sub[y].length; z++) {
                                if (category_sub[y][z] == items[x]["Subcategory"]) {
                                    f_repeated_sub = true;
                                }
                            }
                            if (f_repeated_sub == false) {
                                category_sub[y].push(items[x]["Subcategory"]);
                                id_subcategory[y].push(items[x]["SubcategoryKey"]);
                            }
                        }
                    }
                }
                //end phase 2 - category and Subcategory

                //initialize 3d array for content
                for (x = 0; x < category_main.length; x++) {
                    content_arr.push([]);
                    for (y = 0; y < category_sub[x].length; y++) {
                        content_arr[x].push([]);
                    }
                }

                //by using push to the 3rd dimension, we can trace the number of items, this can't be done in +=
                for (var i = 0; i < (items.length); i++) {
                    for (x = 0; x < category_main.length; x++) {
                        if (category_main[x] == items[i]["Categorization"]) {
                            for (y = 0; y < category_sub[x].length; y++) {
                                if (category_sub[x][y] == items[i]["Subcategory"]) {
                                    content_arr[x][y].push(content_cat_subcat());
                                }
                            }
                        }
                    }
                }

                for (x = 0; x < category_main.length; x++) {
                    title = category_main[x];
                    for (y = 0; y < category_sub[x].length; y++) {
                        subtitle = category_sub[x][y];
                        content += '<div role="tabpanel" ';
                        if (x == 0 && y == 0) {
                            content += 'class="tab-pane active info" ';
                        }
                        else {
                            content += 'class="tab-pane info" ';
                        }
                        content += 'id="assessment_' + id_category[x] + '_' + id_subcategory[x][y] + '"> ' +
                            '<div class="info">' +
                            '<h5>' + title + '</h5> ' +
                            '<p>' + subtitle + '</p></div>';
                        for (z = 0; z < content_arr[x][y].length; z++) {
                            content += content_arr[x][y][z];
                        }
                        content += '</div>';

                    }
                }
                //end phase 3 (end)

//dropdown menu
                for (x = 0; x < category_main.length; x++) {
                    content_dropdown += '<li id="tab_' + id_category[x] + '_box" role="presentation" ';
                    if (x == 0) {
                        content_dropdown += 'class="dropdown active">';
                    }
                    else {
                        content_dropdown += 'class="dropdown">';
                    }
                    content_dropdown += '<a class="tab_category" id="tab_' + id_category[x] + '"href="#" role="tab"data-toggle="tab">' + category_main[x] + '<span' +
                        'class="caret"></span></a>' +
                        '<ul id="assessment_list_' + id_category[x] + '"' +
                        'class="nav nav-tabs materialtabs dropdown-content"role="tablist"> ';

                    for (y = 0; y < category_sub[x].length; y++) {
                        if (x == 0 && y == 0) {
                            content_dropdown += '<li class="active">';
                        }
                        else {
                            content_dropdown += '<li>';
                        }
                        content_dropdown += '<a href="#assessment_' + id_category[x] + '_' + id_subcategory[x][y] +
                            '"aria-controls="assessment_' + id_category[x] + '_' + id_subcategory[x][y] + '"role="tab"' +
                            'data-toggle="tab">' + category_sub[x][y] + '</a> </li> ';
                    }
                    content_dropdown += '</ul></li>';
                }
                $('#assessment-dropdownmenu').html(content_dropdown);

                //end of assessment dropdown menu

                $('#assessment-content').html(content);
                $('.popover_assessment').popover();
                
                //here onwards is the assessment dropdown menu highlight effect
                $('.tab_category').click(function (event) {
                    $('.nav-tabs.materialtabs >li').removeClass("active");
                    $(this).parent().find("a:eq(1)").click();
                });
                
                $('.materialtabs.dropdown-content>li>a').click(function (event) {
                    $('.nav-tabs.materialtabs >li').removeClass("active");
                    $(this).parent().parent().parent().addClass("active");
                });
            })
        }
    })
})
;