/**
 * Created by JaysonGCS on 24/6/16.
 */

/*Scrolling effect on landing page under feature section*/
$(document).ready(function () {
    $(document).on("scroll", onScroll);
});
var temp1 = 1, temp_prev = 0, temp_curr = 0;
var load = 0;

function onScroll(event) {
    var scrollPosition = $(document).scrollTop();

    $('.holder a').each(function () {
        var currLink = $(this);
        var refElement = $(currLink.attr("href"));
        if (refElement.position().top <= scrollPosition && refElement.position().top + refElement.height() > scrollPosition) {
            $('.slide').removeClass("active");
            refElement.addClass("active");
        }
        else {
            refElement.removeClass("active");
        }


        /* start of logic */

        if ($('#slide-0').hasClass('active')) {
            $('.holder').attr('id', 'holder-0');
            temp_curr = 0;
            if ((temp_curr != temp_prev) && temp_prev == 1) {
                temp1 = 0;
            }
            if (temp1 == 0) {
                $('.holder').fadeToggle(100);
                $('.holder').fadeToggle(300);
                temp1 = 1;
            }
            temp_prev = temp_curr;
        }
        else if ($('#slide-1').hasClass('active')) {
            $('.holder').attr('id', 'holder-1');
            temp_curr = 1;
            if (temp_curr != temp_prev) {
                temp1 = 0;
            }
            if (temp1 == 0) {
                $('.holder').fadeToggle(100);
                $('.holder').fadeToggle(300);
                temp1 = 1;
            }
            temp_prev = temp_curr;

        }
        else if ($('#slide-2').hasClass('active')) {
            temp_curr = 2;
            if (temp_curr != temp_prev) {
                temp1 = 0;
            }
            $('.holder').attr('id', 'holder-2');
            if (temp1 == 0) {
                $('.holder').fadeToggle(100);
                $('.holder').fadeToggle(300);
                temp1 = 1;
            }
            temp_prev = temp_curr;

        }
        else if ($('#slide-3').hasClass('active')) {
            temp_curr = 3;
            if (temp_curr != temp_prev) {
                temp1 = 0;
            }
            $('.holder').attr('id', 'holder-3');
            if (temp1 == 0) {
                $('.holder').fadeToggle(100);
                $('.holder').fadeToggle(300);
                temp1 = 1;
            }
            temp_prev = temp_curr;
        }
        else if ($('#slide-4').hasClass('active')) {
            temp_curr = 4;
            if (temp_curr != temp_prev) {
                temp1 = 0;
            }
            $('.holder').attr('id', 'holder-4');
            if (temp1 == 0) {
                $('.holder').fadeToggle(100);
                $('.holder').fadeToggle(300);
                temp1 = 1;
            }
            temp_prev = temp_curr;
        }
        else if ($('#slide-5').hasClass('active')) {
            temp_curr = 5;
            if (temp_curr != temp_prev) {
                temp1 = 0;
            }
            $('.holder').attr('id', 'holder-5');
            if (temp1 == 0) {
                $('.holder').fadeToggle(100);
                $('.holder').fadeToggle(300);
                temp1 = 1;
            }
            temp_prev = temp_curr;
        }
        /* end of logic */
        if ($('.slide').hasClass('active')) {
            $('.holder').css('background-attachment', 'fixed');

        }
        else {
            $('.holder').css('background-attachment', '');
        }
        /*testing here*/
        if ($('.slide#slide-0').hasClass('active') == false) {
            $('.slide#slide-0').css('background-image', 'url(../images/Slide0.jpg)');
            $('.slide#slide-0').css('background-size', 'cover');

        }
        else {
            $('.slide#slide-0').css('background-image', '');

        }
    });

    if (load != 5) {

        if (load == 0) {
            $('.holder').attr('id', 'holder-1');
            load++;
        }
        if (load == 1) {
            $('.holder').attr('id', 'holder-2');
            load++;
        }
        if (load == 2) {
            $('.holder').attr('id', 'holder-3');
            load++;
        }
        if (load == 3) {
            $('.holder').attr('id', 'holder-4');
            load++;
        }
        if (load == 4) {
            $('.holder').attr('id', 'holder-5');
            load++;
        }
    }
}

