var app = require('../app');
var express = require('express');
var router = express.Router();
var mongojs = require('mongojs');

var db = mongojs('mongodb://localhost:27017/test');
var userDB = db.collection('User1DB');


/*  Function: POST Answer and Notes from the Assessment Page into the Database
    Inputs: 1) Instance saved variables of ReportDate, Assessor and assessment_id
            2) User Inputs of Answers and Notes from Assessment Page
    Output: Update Question Answers and Notes in the Report from the User Database
 */
router.post('/', function (req, res, next) {
    console.log(req.body);
    var IDArray = req.body.assessmentIDs;
    var ansArray = req.body.assessmentAns;
    var notes = req.body.assessmentNotes;
    var reportdate = new Date(req.body.reportDate);
    reportdate.setSeconds(1);
    var assessor = req.body.reportAssessor;
    var dateUp = new Date(reportdate);
    dateUp.setSeconds(50);

    new Promise(function (resolve, reject) {
        for (i = 0; i < IDArray.length; i++) {
            var ID = IDArray[i];
            var answer = ansArray[i];
            switch (answer) {
                case "FC":
                    userDB.update({
                        ReportDate: {$gte: reportdate, $lt: dateUp},
                        Assessor: assessor,
                        "Questions.Index": IDArray[i]
                    }, {$set: {"Questions.$.Answer": "Fully Compliant"}});
                    break;
                case "PC":
                    userDB.update({
                        ReportDate: {$gte: reportdate, $lt: dateUp},
                        Assessor: assessor,
                        "Questions.Index": ID
                    }, {$set: {"Questions.$.Answer": "Partially Compliant"}});
                    break;
                case "NC":
                    userDB.update({
                        ReportDate: {$gte: reportdate, $lt: dateUp},
                        Assessor: assessor,
                        "Questions.Index": IDArray[i]
                    }, {$set: {"Questions.$.Answer": "Not Compliant"}});
                    break;
                case "NA":
                    userDB.update({
                        ReportDate: {$gte: reportdate, $lt: dateUp},
                        Assessor: assessor,
                        "Questions.Index": ID
                    }, {$set: {"Questions.$.Answer": "Not Applicable"}});
                    break;
                default:
                    console.log("Error");
                    break;
            }
            if (notes[i]!=""){
                userDB.update({
                    ReportDate: {$gte: reportdate, $lt: dateUp},
                    Assessor: assessor,
                    "Questions.Index": ID
                }, {$set: {"Questions.$.Notes":notes[i]}})
            }
            if (i == IDArray.length - 1) {
                console.log("Finished POSTing");
                resolve(i)
            }
        }
    }).then(function (input) {
        res.redirect('./userpanel');
    }).catch(function (error) {
        console.log("Error");
    })
});

module.exports = router;