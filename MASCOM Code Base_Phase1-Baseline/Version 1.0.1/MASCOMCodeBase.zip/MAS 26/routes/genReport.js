var app = require('../app');
var express = require('express');
var router = express.Router();
var mongojs = require('mongojs');
var Promise = require('promise');

var db = mongojs('mongodb://localhost:27017/test');
var questionsDB = db.collection('TestImport');
var userDB = db.collection('User1DB');


/*  Function: POST/Generate a Report and return it to frontend for Assessment Generation
    Inputs: 1) profiling_id for sequence of Profiling Questions
            2) User Inputs of profiling answers, Report Date and Assessor Name
    Outputs: Report with unanswered and pre-selected answers for frontend generation of Assessment Page
*/
router.post('/', function (req, res, next) {
    console.log("Inside genReport");

    /*  Function: Takes the User Inputs of Profiling Answers to query the database for Assessment Questions
                    to pre-select as "Not Applicable
        Inputs: Index of Profiling Question in which the User has selected "No"
        Outputs: Concatenates all Assessment Question Indexes related to the passed in Profiling Question
                    Index to mark as "Not Applicable"
     */
    var profilingArray = function profilingEnact(index) {
        return new Promise(function (resolve, reject) {
            questionsDB.findOne({Index: index}, function (err, data) {
                if (data == null) {
                    console.log("null");
                    resolve();
                } else {
                    affectedQuestions = affectedQuestions.concat(data.Questions);
                    resolve(affectedQuestions);
                }
            });
        });
    };

    /*  Function: Adds Assessment Questions fields into the empty Report, by calling into the Questions
                    database, and saving relevant fields into the specified Report in the USer database,
                    with Answers pre-selected as "Not Applicable" or "" where appropriate.
        Inputs: Array of Assessment Question Indexes to be marked as "Not Applicable"
        Outputs: None
     */
    function postReport(affectedQuestions) {
        return new Promise(function (fulfil, escape) {
            var affectedQuestionsArray = [].concat.apply([], affectedQuestions);
            var maxItems;
            questionsDB.find({Latest:"TRUE"}).count(function (err, data2) {
                maxItems = data2;
            });

            var count = 0;
            questionsDB.find({Latest:"TRUE"}).forEach(function (err, u) {
                if (err) throw err;
                if (u != null) {
                    new Promise(function (resolve, reject) {
                        if (affectedQuestionsArray.indexOf(u.Index) > -1) {
                            userDB.update({ReportDate: {$gte: reportdate, $lt: dateUp}}, {
                                $addToSet: {
                                    Questions: {
                                        "Index": u.Index,
                                        "Question": u.Question,
                                        "Categorization": u.Categorization,
                                        "CategorizationKey": u.CategorizationKey,
                                        "Subcategory": u.Subcategory,
                                        "SubcategoryKey": u.SubcategoryKey,
                                        "Reference": u.Reference,
                                        "ContentofReference": u.ContentofReference,
                                        "Answer": "Not Applicable"
                                    }
                                }
                            });
                            count++;
                            resolve(u);
                        } else {
                            userDB.update({ReportDate: {$gte: reportdate, $lt: dateUp}}, {
                                $addToSet: {
                                    Questions: {
                                        "Index": u.Index,
                                        "Question": u.Question,
                                        "Categorization": u.Categorization,
                                        "CategorizationKey": u.CategorizationKey,
                                        "Subcategory": u.Subcategory,
                                        "SubcategoryKey": u.SubcategoryKey,
                                        "Reference": u.Reference,
                                        "ContentofReference": u.ContentofReference,
                                        "Answer": ""
                                    }
                                }
                            });
                            count++;
                            resolve(u);
                        }
                    }).then(function (item) {
                        if (item.hasOwnProperty('Mandatory')) {
                            userDB.update({
                                ReportDate: {$gte: reportdate, $lt: dateUp},
                                "Questions.Index": item.Index
                            }, {$set: {"Questions.$.Mandatory": "TRUE"}});
                            if (count == maxItems) {
                                fulfil(count);
                            }
                        } else {
                            if (count == maxItems) {
                                fulfil(count);
                            }
                        }
                    }).catch(function (error) {
                        console.log("Error");
                    });
                }
            })
        })
    }

    /*  Function: Finds the Report that was worked on, and return it to generate frontend of Assessment Page
        Inputs: ReportDate and Assessor to identify which Report to GET
        Outputs: Report to generate Report on the frontend
     */
    function returnData(data3) {
        userDB.findOne({
            ReportDate: {$gte: reportdate, $lt: dateUp},
            Assessor: req.body.reportAssessor
        }, function (err, data4) {
            console.log("Data length = "+data4.Questions.length);
            res.send(data4);
            return data3;
        });
    }

    /*Preparing of Variables for Database Operations*/
    var answers = req.body.profilingAnswer;
    var IDArray = [];
    var affectedQuestions = [];

    for (var iter = 0; iter < answers.length; iter++) {
        if (answers[iter] == "No") {
            IDArray.push(req.body.profilingIDs[iter]);
        }
    }

    reportDATE = req.body.reportDate;
    reportDATE = reportDATE.split("/");
    var reportdate = new Date(req.body.currDate);
    reportdate.setDate(reportDATE[0]);
    reportdate.setMonth(reportDATE[1]-1);
    reportdate.setYear(reportDATE[2]);
    reportdate.setSeconds(5);
    var dateUp = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate(), reportdate.getHours(), reportdate.getMinutes(), 50, 0);

    /*Create an empty Report using the User inputs of Report Date and Assessor name*/
    userDB.insert({ReportDate: reportdate, Assessor: req.body.reportAssessor, Questions: []});

    /*Synchronous calls for the profilingArray,postReport and then returnData functions*/
    Promise.all(IDArray.map(profilingArray)).then(postReport).then(returnData).catch(function (error) {
        console.log("Error Catch" + error)
    });
});

module.exports = router;