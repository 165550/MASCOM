var express = require('express');
var router = express.Router();

/* GET User Panel page and load userpanel.html */

router.get('/userpanel', function(req, res, next) {
        res.render('userpanel');
});

module.exports = router;
