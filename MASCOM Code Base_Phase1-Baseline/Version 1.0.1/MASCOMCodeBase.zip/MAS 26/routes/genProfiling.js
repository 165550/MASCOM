var express = require('express');
var router = express.Router();
var mongojs = require('mongojs');

var db = mongojs('mongodb://localhost:27017/test');
var myCollection = db.collection('TestImport');


/* GET Profiling Questions from the Database, and return it to the frontend JavaScript for display */

router.get('/', function(req, res, next) {
    myCollection.find({Profiling:"TRUE"}).toArray(function(err,data){
        res.send(data);
    })
});

module.exports = router;
