/**
 * Created by JaysonGCS on 1/7/16.
 */
window.flag_profiling_assessment=false;

$(function () {
    $('#up-body-assessment-profilingintro').hide();
    $('#up-body-assessment-assessment').hide();

    $('.navbar-nav#sidemenuonly>li').click(function () {
        $('#up-body-assessment-profilingintro').hide();
        $('#up-body-assessment-assessment').hide();
    });

    $('#assessment-btn-profiling-1').click(function () {


        var flag = '';
        for (var i = 0; i<profiling_id.length; i++) {
            if ($('[name="' + profiling_id[i] + '"]').is(':checked') == true) {
                flag = true;
            }
            else {
                flag = false;
                break;
            }
        }

        if (flag == true) {
            $('#up-body-assessment-profiling').hide();
            $('#up-body-assessment-profilingintro').fadeIn('slow');
            flag_profiling_assessment=true;
        }
        else {
            alert("Profiling incomplete!");
            flag_profiling_assessment=false;

        }
    });

    $('#assessment-btn-profiling-2').click(function () {
        $('#up-body-assessment-profilingintro').hide();
        $('#up-body-assessment-assessment').fadeIn('slow');

    });

    $('#assessment-btn-profiling-2-back').click(function () {
        $('#up-body-assessment-profilingintro').hide();
        $('#up-body-assessment-profiling').fadeIn('slow');

    });

    $('#assessment-btn-profiling-2-startassessment').click(function () {
        $('#up-body-assessment-profilingintro').hide();
        $('#up-body-assessment-assessment').fadeIn('slow');

    });

    $('#assessment-btn-profiling-assesssment-back').click(function () {
        $('#up-body-assessment-assessment').hide();
        $('#up-body-assessment-profilingintro').fadeIn('slow');

    });

    $('#assessment-btn-assessment-submit-1').click(function () {
        var flag = '';
        for (var i = 0; i<assessment_id.length; i++) {
            if ($('[name="' + assessment_id[i] + '"]').is(':checked') == true) {
                flag = true;
            }
            else {
                flag = false;
                break;
            }
        }

        /*  if ($('[name="3"]').is(':checked') == true&&$('[name="40"]').is(':checked') == true) {
         flag = true;
         }*/

        if (flag == true) {
            $('#up-body-assessment-assessment').hide();
            $('#up_report').click();
        }
        else {
            alert("Assessment incomplete!");
        }
    });
    $('#assessment-btn-assessment-submit-2').click(function () {
        var flag = '';
        for (var i = 0; i<assessment_id.length; i++) {
            if ($('[name="' + assessment_id[i] + '"]').is(':checked') == true) {
                flag = true;
            }
            else {
                flag = false;
                break;
            }
        }

        /*  if ($('[name="3"]').is(':checked') == true&&$('[name="40"]').is(':checked') == true) {
         flag = true;
         }*/

        if (flag == true) {
            $('#up-body-assessment-assessment').hide();
            $('#up_report').click();
        }
        else {
            alert("Assessment incomplete!");
        }
    });

    //here onwards is the assessment dropdown menu highlight effect
    //move to jsonassessment
});