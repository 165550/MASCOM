/**
 * Created by JaysonGCS on 30/6/16.
 */
$(function () {
    $(document).ready(function () {
        $('[data-toggle="popover"]').popover();
    });
    $(document).ready(function () {
        $('[data-toggle="popover2"]').popover();
    });

    $('#up-body-assessment-profiling').hide();
    $('#up-body-reports').hide();
    $('#up-body-monitor').hide();


    $('.navbar-nav#sidemenuonly>li').click(function (e) {
        e.preventDefault();
        if ($(this).parent().find('#up_sum').hasClass('active')) {
            //$('#up-body-summary').addClass('active');
            $('#up-body-summary').fadeIn('slow');
        }
        else {
            //$('#up-body-summary').removeClass('active');
            $('#up-body-summary').hide();
        }
        if ($(this).parent().find('#up_assessment').hasClass('active')) {
            //$('#up-body-assessment-profiling').addClass('active');
            $('#up-body-assessment-profiling').fadeIn('slow');
        }
        else {
            //$('#up-body-assessment-profiling').removeClass('active');
            $('#up-body-assessment-profiling').hide();
        }

        //these 2 conditions are for side bar menu report and monitoring to control box content hide and show
     /*   if ($('#up_report>.dropdown-lvl1>ul>li>a').hasClass('active') == false) {
            if ($(this).parent().find('#up_report').hasClass('active')) {
                //$('#up-body-reports').addClass('active');
                $('#up-body-reports').fadeIn('slow');
            }
            else {
                //$('#up-body-reports').removeClass('active');
                $('#up-body-reports').hide();

            }
            if ($(this).parent().find('#up_monitor').hasClass('active')) {
                //$('#up-body-monitor').addClass('active');
                $('#up-body-monitor').fadeIn('slow');

            }
            else {
                //$('#up-body-monitor').removeClass('active');
                $('#up-body-monitor').hide();
            }
        }
        else if ($('#up_monitor>.dropdown-lvl1>ul>li>a').hasClass('active') == false) {
            if ($(this).parent().find('#up_report').hasClass('active')) {
                //$('#up-body-reports').addClass('active');
                $('#up-body-reports').fadeIn('slow');
            }
            else {
                //$('#up-body-reports').removeClass('active');
                $('#up-body-reports').hide();

            }
            if ($(this).parent().find('#up_monitor').hasClass('active')) {
                //$('#up-body-monitor').addClass('active');
                $('#up-body-monitor').fadeIn('slow');

            }
            else {
                //$('#up-body-monitor').removeClass('active');
                $('#up-body-monitor').hide();
            }
        }*/

    });
})
;