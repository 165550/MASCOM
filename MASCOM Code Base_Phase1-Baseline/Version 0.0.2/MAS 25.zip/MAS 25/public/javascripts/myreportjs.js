/**
 * Created by JaysonGCS on 5/7/16.
 */

window.fully_compliant = 0, partially_compliant = 0, not_compliant = 0, not_applicable = 0;
window.fully_compliant_mandatory = 0, partially_compliant_mandatory = 0, not_compliant_mandatory = 0, not_applicable_mandatory = 0;

window.data_ic_fc = 0, data_ic_pc = 0, data_ic_nc = 0, data_ic_na = 0;
window.data_trm_fc = 0, data_trm_pc = 0, data_trm_nc = 0, data_trm_na = 0;
window.data_bcm_fc = 0, data_bcm_pc = 0, data_bcm_nc = 0, data_bcm_na = 0;
window.data_out_fc = 0, data_out_pc = 0, data_out_nc = 0, data_out_na = 0;

window.total_compliant_mandatory=0,total_compliant_organization=0,
    total_compliant_ic=0,total_compliant_trm=0,total_compliant_bcm=0,total_compliant_out=0;

window.monitoring_date = [];


$(document).ready(function () {
    /* var data = [],
     series = Math.floor(Math.random() * 6) + 3;

     for (var i = 0; i < series; i++) {
     data[i] = {
     label: "Series" + (i + 1),
     data: Math.floor(Math.random() * 100) + 1
     }

     }*/

    function labelFormatter(label, series) {
        return "<div style='font-size:8pt; text-align:center; padding:2px; color:white;'>" + label + "<br/>" + Math.round(series.percent) + "%</div>";
    }
// WTFF ??????????????????????????????????????????????????????????????????????????
    var data2 = [{label: "Do", data: 5}, {label: "you", data: 3}, {label: "wanna", data: 4}, {
        label: "dinner?",
        data: 5
    }];

    var data_overview = [{label: "FC ("+fully_compliant+"/"+total_compliant_organization+")", data: fully_compliant,color:"#4DA74D"},
        {label: "PC ("+partially_compliant+"/"+total_compliant_organization+")", data: partially_compliant,color:"#EDC240"},
        {label: "NC ("+not_compliant+"/"+total_compliant_organization+")", data: not_compliant,color:"#CB4B4B"},
        {label: "NA ("+not_applicable+"/"+total_compliant_organization+")", data: not_applicable,color:"grey"}];

    var data_mandatory = [{label: "FC ("+fully_compliant_mandatory+"/"+total_compliant_mandatory+")", data: fully_compliant_mandatory,color:"#4DA74D"},
        {label: "PC ("+partially_compliant_mandatory+"/"+total_compliant_mandatory+")", data: partially_compliant_mandatory,color:"#EDC240"},
        {label: "NC ("+not_compliant_mandatory+"/"+total_compliant_mandatory+")", data: not_compliant_mandatory,color:"#CB4B4B"},
        {label: "NA ("+not_applicable_mandatory+"/"+total_compliant_mandatory+")", data: not_applicable_mandatory, color:"grey"}];
    
    //4 data pie chart under details
    var data_ic = [
        {label: "FC ("+data_ic_fc+"/"+total_compliant_ic+")", data: data_ic_fc,color:"#4DA74D"},
        {label: "PC ("+data_ic_pc+"/"+total_compliant_ic+")", data: data_ic_pc,color:"#EDC240"},
        {label: "NC ("+data_ic_nc+"/"+total_compliant_ic+")", data: data_ic_nc,color:"#CB4B4B"},
        {label: "NA ("+data_ic_na+"/"+total_compliant_ic+")", data: data_ic_na,color:"grey"}];
    var data_trm = [{label: "FC ("+data_trm_fc+"/"+total_compliant_trm+")", data: data_trm_fc,color:"#4DA74D"},
        {label: "PC ("+data_trm_pc+"/"+total_compliant_trm+")", data: data_trm_pc,color:"#EDC240"},
        {label: "NC ("+data_trm_nc+"/"+total_compliant_trm+")", data: data_trm_nc,color:"#CB4B4B"},
        {label: "NA ("+data_trm_na+"/"+total_compliant_trm+")", data: data_trm_na,color:"grey"}];
    var data_bcm = [{label: "FC ("+data_bcm_fc+"/"+total_compliant_bcm+")", data: data_bcm_fc,color:"#4DA74D"},
        {label: "PC ("+data_bcm_pc+"/"+total_compliant_bcm+")", data: data_bcm_pc,color:"#EDC240"},
        {label: "NC ("+data_bcm_nc+"/"+total_compliant_bcm+")", data: data_bcm_nc,color:"#CB4B4B"},
        {label: "NA ("+data_bcm_na+"/"+total_compliant_bcm+")", data: data_bcm_na,color:"grey"}];
    var data_out = [{label: "FC ("+data_out_fc+"/"+total_compliant_out+")", data: data_out_fc,color:"#4DA74D"},
        {label: "PC ("+data_out_pc+"/"+total_compliant_out+")", data: data_out_pc,color:"#EDC240"},
        {label: "NC ("+data_out_nc+"/"+total_compliant_out+")", data: data_out_nc,color:"#CB4B4B"},
        {label: "NA ("+data_out_na+"/"+total_compliant_out+")", data: data_out_na,color:"grey"}];

    $('#popover_samplereport').hover(function () {
        $.plot($("#pie_samplereport_hover"), data_overview, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 3 / 4,
                        formatter: labelFormatter,
                        background: {
                            opacity: 0.5,
                            color: "#000"
                        }
                    }
                }
            },
            legend: {
                show: false
            }
        });

    });


    $('#up-body-samplereport').hide();


    $('#report_samplereport').click(function () {
        $('#up-body-reports').hide();
        $('#up-body-samplereport').fadeIn('slow');


        $.plot($("#pie_overview"), data_overview, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 2 / 4,
                        formatter: labelFormatter,
                        background: {
                            opacity: 0.5,
                            color: "#000"
                        }
                    }
                }
            },
            legend: {
                show: true
            }
        });

        $.plot($("#pie_mandatory"), data_mandatory, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 2 / 4,
                        formatter: labelFormatter,
                        background: {
                            opacity: 0.5,
                            color: "#000"
                        }
                    }
                }
            },
            legend: {
                show: true
            }
        });

        $.plot($("#pie_ic"), data_ic, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 3/5,
                        formatter: labelFormatter,
                        background: {
                            opacity: 0.5,
                            color: "#000"
                        }
                    }
                }
            },
            legend: {
                show: true
            }
        });
        $.plot($("#pie_trm"), data_trm, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 3/5,
                        formatter: labelFormatter,
                        background: {
                            opacity: 0.5,
                            color: "#000"
                        }
                    }
                }
            },
            legend: {
                show: true
            }
        });
        $.plot($("#pie_bcm"), data_bcm, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 3/5,
                        formatter: labelFormatter,
                        background: {
                            opacity: 0.5,
                            color: "#000"
                        }
                    }
                }
            },
            legend: {
                show: true
            }
        });
        $.plot($("#pie_out"), data_out, {
            series: {
                pie: {
                    show: true,
                    radius: 1,
                    label: {
                        show: true,
                        radius: 3/5,
                        formatter: labelFormatter,
                        background: {
                            opacity: 0.5,
                            color: "#000"
                        }
                    }
                }
            },
            legend: {
                show: true
            }
        });
        

        
    });

    
    
    

    $(".report_filter").select2({
        placeholder: "Filter",
        closeOnSelect: false,
        tokenSeparators: [',', ' ']
    });

    $('#report_filter').on("select2:select", function (e) {
        //   alert($('#monitoring_filter').val());
        $('#table_report>tbody tr').hide();
        var filter_items = $('#report_filter').val();
        // var filter_items_tag = '';
        for (var i = 0; i < filter_items.length; i++) {

            // filter_items_tag +="."+ filter_items[i];

            /*   if (filter_items[i] == "ic") {
             $('#table_monitor .ic').show();
             }
             if (filter_items[i] == "trm") {
             $('#table_monitor .trm').show();

             }
             if (filter_items[i] == "bcm") {
             $('#table_monitor .bcm').show();

             }
             if (filter_items[i] == "out") {
             $('#table_monitor .out').show();

             }*/

            $('#table_report .'+filter_items[i]).show();
        }
    });
    $('#report_filter').on("select2:unselect", function (e) {
        //alert($('#monitoring_filter').val());
        if ($('#report_filter').val() == null) {
            $('#table_report>tbody tr').show();
        }
        else {
            $('#table_report>tbody tr').hide();
            var filter_items = $('#report_filter').val();
            for (var i = 0; i < filter_items.length; i++) {
                $('#table_report .'+filter_items[i]).show();
            }
        }
    });

});