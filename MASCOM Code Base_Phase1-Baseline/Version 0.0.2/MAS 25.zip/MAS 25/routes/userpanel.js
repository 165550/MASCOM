var express = require('express');
var router = express.Router();
//var mongojs = require('mongojs');

//var db = mongojs('mongodb://localhost:27017/test');
//var myCollection = db.collection('TestImport');


/* GET home page. */

router.get('/userpanel', function(req, res, next) {
    console.log("Here2");
    res.render('userpanel',{});
});

module.exports = router;
