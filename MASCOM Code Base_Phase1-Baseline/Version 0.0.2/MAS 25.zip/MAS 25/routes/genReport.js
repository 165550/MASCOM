var app = require('../app');
var express = require('express');
var router = express.Router();
var mongojs = require('mongojs');
var Promise = require('promise');

var db = mongojs('mongodb://localhost:27017/test');
var questionsDB = db.collection('TestImport');
var userDB = db.collection('User1DB');


router.post('/', function (req, res, next) {
    console.log("Inside genReport");

    var profilingArray = function profilingEnact(index) {
        return new Promise(function (resolve, reject) {
            questionsDB.findOne({Index: index}, function (err, data) {
                if (data == null) {
                    console.log("null");
                    resolve();
                } else {
                    affectedQuestions = affectedQuestions.concat(data.Questions);
                    resolve(affectedQuestions);
                }
            });
        });
    };

    function postReport(affectedQuestions) {
        return new Promise(function (fulfil, escape) {
            var affectedQuestionsArray = [].concat.apply([], affectedQuestions);
            var maxItems;
            questionsDB.find({Profiling:{$exists: 0}}).count(function (err, data2) {
                maxItems = data2;
            });

            var count = 0;
            questionsDB.find({Profiling: {$exists: 0}}).forEach(function (err, u) {
                if (err) throw err;
                if (u != null) {
                    new Promise(function (resolve, reject) {
                        if (affectedQuestionsArray.indexOf(u.Index) > -1) {
                            userDB.update({ReportDate: {$gte: reportdate, $lt: dateUp}}, {
                                $addToSet: {
                                    Questions: {
                                        "Index": u.Index,
                                        "Question": u.Question,
                                        "Categorization": u.Categorization,
                                        "CategorizationKey": u.CategorizationKey,
                                        "Subcategory": u.Subcategory,
                                        "SubcategoryKey": u.SubcategoryKey,
                                        "Reference": u.Reference,
                                        "ContentofReference": u.ContentofReference,
                                        "Answer": "Not Applicable"
                                    }
                                }
                            });
                            count++;
                            resolve(u);
                        } else {
                            userDB.update({ReportDate: {$gte: reportdate, $lt: dateUp}}, {
                                $addToSet: {
                                    Questions: {
                                        "Index": u.Index,
                                        "Question": u.Question,
                                        "Categorization": u.Categorization,
                                        "CategorizationKey": u.CategorizationKey,
                                        "Subcategory": u.Subcategory,
                                        "SubcategoryKey": u.SubcategoryKey,
                                        "Reference": u.Reference,
                                        "ContentofReference": u.ContentofReference,
                                        "Answer": ""
                                    }
                                }
                            });
                            count++;
                            resolve(u);
                        }
                    }).then(function (item) {
                        if (item.hasOwnProperty('Mandatory')) {
                            userDB.update({
                                ReportDate: {$gte: reportdate, $lt: dateUp},
                                "Questions.Index": item.Index
                            }, {$set: {"Questions.$.Mandatory": "TRUE"}});
                            if (count == maxItems) {
                                fulfil(count);
                            }
                        } else {
                            if (count == maxItems) {
                                fulfil(count);
                            }
                        }
                    }).catch(function (error) {
                        console.log("Error");
                    });
                }
            })
        })
    }

    function returnData(data3) {
        console.log("Finally we are here!");
        userDB.findOne({
            ReportDate: {$gte: reportdate, $lt: dateUp},
            Assessor: req.body.reportAssessor
        }, function (err, data4) {
            console.log("data4 is the Report Json");
            res.send(data4);
            return data3;
        });
    }

    console.log(req.body);

    var answers = req.body.profilingAnswer;
    var IDArray = [];
    var affectedQuestions = [];

    for (var iter = 0; iter < answers.length; iter++) {
        if (answers[iter] == "No") {
            IDArray.push(req.body.profilingIDs[iter]);
        }
    }

    var reportDATE = req.body.reportDate.split("/");
    console.log(reportDATE);
    /*
    switch (reportDATE[1]) {
        case "January":
            reportDATE[1] = "00";
            break;
        case "February":
            reportDATE[1] = "01";
            break;
        case "March":
            reportDATE[1] = "02";
            break;
        case "April":
            reportDATE[1] = "03";
            break;
        case "May":
            reportDATE[1] = "04";
            break;
        case "June":
            reportDATE[1] = "05";
            break;
        case "July":
            reportDATE[1] = "06";
            break;
        case "August":
            reportDATE[1] = "07";
            break;
        case "September":
            reportDATE[1] = "08";
            break;
        case "October":
            reportDATE[1] = "09";
            break;
        case "November":
            reportDATE[1] = "10";
            break;
        case "December":
            reportDATE[1] = "11";
            break;
    }
    */

    var reportdate = new Date(reportDATE[2], reportDATE[1]-1, reportDATE[0], 8, 0, 0, 0);
    userDB.insert({ReportDate: reportdate, Assessor: req.body.reportAssessor, Questions: []});
    var dateUp = new Date(reportdate.getFullYear(), reportdate.getMonth(), reportdate.getDate(), reportdate.getHours(), reportdate.getMinutes() + 1, 0, 0);

    Promise.all(IDArray.map(profilingArray)).then(postReport).then(returnData).catch(function (error) {
        console.log("Error Catch" + error)
    });
});

module.exports = router;