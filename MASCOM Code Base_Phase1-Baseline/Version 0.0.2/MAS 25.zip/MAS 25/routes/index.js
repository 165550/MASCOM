var express = require('express');
var router = express.Router();
//var mongojs = require('mongojs');

//var db = mongojs('mongodb://localhost:27017/test');
//var myCollection = db.collection('TestImport');


/* GET home page. */

router.get('/', function(req, res, next) {
  res.render('index',{});
});

/*
router.get('/',function(req,res){
    myCollection.find({"Sub-category":"Audit"},{},function(err,data){
        res.render('index', {myData: data, title:"JQ Trying Shit"});
    })
});

router.post('/postNew',function(req,res){
    var newItem = req.body.newRef;
    myCollection.insert({"Sub-category":"Audit","Reference":newItem});
    res.redirect('/');
});
*/
module.exports = router;
